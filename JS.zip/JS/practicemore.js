/* 

// Function to Get the Date in JavaScript
const getTheDate = (date = new Date()) => {
	const days = date.getDate() + 1;
	const months = date.getMonth() + 1;
	const year = date.getFullYear();

	return `Today's Date is: ${months}/${days}/${year}`;
};

console.log(getTheDate());

*/

/*
// function to get the file extension name of a file

let getFileExtension = (str) => str.slice(str.lastIndexOf('.'));

console.log(getFileExtension('webpack.config.js.ext.ympa'));

*/

/*
// Function to replace every character in a string with the character following it in the alphabet

let moveCharForward = (str) =>
	str
		.split('')
		.map((char) => {
			if (char === 'z') {
				return 'a';
			} else {
				String.fromCharCode(char.charCodeAt(0) + 1);
			}
		})
		.join('');

console.log(moveCharForward('efhg'));
console.log(moveCharForward('optd'));

*/

// function to create a new string adding the word 'New!' in front of it. If the string begins with the word "New!", then return the original string.

/*
let newFunc = (str) => {
	if (str.indexOf('New!') === 0) {
		return str;
	}
	return `New! ${str}`;
};

// OR

let newFunc = (str) => (str.indexOf('New!') === 0 ? str : `New! ${str}`);

console.log(newFunc('New! gotcha'));
console.log(newFunc('gotcha'));
*/

/*
// Function to take the first 3 char and the last 3 char and put them together but if the str is not up to 6, return the string.

let joinFirstAndLast3 = (str) => {
	if (str.length < 6) {
		console.log(`You need to enter at least 6 characters`);
		return str;
	} else {
		const first3 = str.slice(0, 3);
		const last3 = str.slice(str.length - 3);
		return `${first3}${last3}`;
	}
};

console.log(joinFirstAndLast3('whobeyouyou'));
console.log(joinFirstAndLast3('whoby'));
console.log(joinFirstAndLast3('whobeyouyo'));
*/

/*
// Function to return the first half of a string if the string's length is an odd number
let extractFirstHalf = (str) => {
	if (str.length % 2 === 0) {
		const num = str.length / 2;
		return str.slice(0, num);
	}
	return `The string's length is an odd number`;
};
console.log(extractFirstHalf('abasdjdk'));
console.log(extractFirstHalf('abasdjd'));
*/

/** 
// function to concatenate 2 strings except their first characters
// easy to do it for 2 strings but the rest operator was for more than 2 but didnt work 
let concatExceptFirst = (...str) => 
// return str.reduce((prev, curr) => {
// 	return `${prev.slice(1)}${curr.slice(1)}`;
// });

console.log(concatExceptFirst('rtgffg', 'hfevhfi', 'hejef'));
*/

/*
//Function that takes 2 numbers and returns the number closest to 100

let closestTo100 = (a, b) => (Math.abs(100 - a) < Math.abs(100 - b) ? a : b);
console.log(closestTo100(96, 97));
console.log(closestTo100(100, 97));
console.log(closestTo100(40, 197));
console.log(closestTo100(-1, -2));
console.log(closestTo100(1, 102));
*/

/* write a javascript program that finds the number of even values from 1 up to a number

const countEvenNumbers = (arr) => arr.filter(num => num%2 === 0).length;

const createArrayOfNumbers = (num) => {
    const arrayNumbers = [];
    for (let i = 1; i<= num; i++){
        arrayNumbers.push(i);
    }
    return arrayNumbers;
}

console.log(countEvenNumbers(createArrayOfNumbers(89)));
console.log(countEvenNumbers(createArrayOfNumbers(15)));
console.log(countEvenNumbers(createArrayOfNumbers(20)));

*/

/*
// function to check if array of numbers is sorted in ascending order.

let isInAscendingOrder = (arr) => {
	for (let i = 0; i < arr.length; i++) {
		if (arr[i + 1] < arr[i]) {
			return false;
		}
	}
	return true;
};

console.log(isInAscendingOrder([ 1, 4, 6, 7, 8 ]));
console.log(isInAscendingOrder([ 1, 5, 6, 3, 8 ]));
console.log(isInAscendingOrder([ 1, 5, 9, 2 ]));
*/

/*
// function to get the largest even number from an array of integers...THE LONG METHOD

let getEven = (arr) => {
	let newArray = [];
	for (let i = 0; i < arr.length; i++) {
		if (arr[i] % 2 === 0) {
			newArray.push(arr[i]);
		}
	}
	return newArray;
};

let largest = (arr6) => {
	highest = arr6[0];
	for (i = 0; i < arr6.length; i++) {
		if (arr6[i] > highest) {
			highest = arr6[i];
		}
	}
	return highest;
};

console.log(largest(getEven([ 1, 3, 5, 6, 8 ])));
console.log(largest(getEven([ 1, 20, 5, 6, 8 ])));
console.log(largest(getEven([ 1, 3, 5, 6, 8, 78 ])));

//THE SHORT METHOD

const largestEven = (arr) => Math.max(...arr.filter(num => num % 2 === 0 ));

//.filter filters out unspecified specifications.
*/

// FUNCTION TO REPLACE FIRST CHARACTER IN A STRING.
/*
let replaceFirstDigit = (str) => str.replace(/[0-9]/, '$')
*/

