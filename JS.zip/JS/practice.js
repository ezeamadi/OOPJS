/*
// Function to show prime numbers between 0 // and a particular number

showPrimes(10);

function showPrimes(limit) {
	for (let i = 2; i <= limit; i++) {
        
        let isPrime = true;
		for (let j = 2; j < i; j++) {
			if (i % j === 0) {
				isPrime = false;
				break;
			}
		}
        if (isPrime) 
            console.log(i);
	}
}

*/

/* 
// Function to find the number of occurence of a particular number in an array

const numbers = [ 1, 2, 3, 4, 2, 1, 3, 4, 1 ];

const count = countOccurence(numbers, 1);

function countOccurence(array, searchElement) {
	let count = 0;
	for (let element of array) {
		if (element === searchElement) {
			count++;
		}
	}
	return count;
}
*/

// const numbers = [ 1, 2, 3, 4, 2, 1, 3, 4, 1 ];

// const count = countOccurence(numbers, 1);
// console.log(count);

// function countOccurence2(array, searchElement) {
// 	array.reduce((accumulator, currentValue) => {
// 		const occurence = currentValue === searchElement ? 1 : 0;
// 		return accumulator + occurence;
// 	}, 0);
// }

/*
// Function to use the reduce method to find the maximum value in an array

function getMax(array) {
	if (array.length === 0) return undefined;

	return array.reduce((a, b) => (a > b ? a : b));
}

*/

/*
// Get all the movies in 2018 with rating > 4
// Sort them by their rating
// Descending order
// Pick their title

const movies = [
	{ title: 'a', year: 2018, rating: 4.5 },
	{ title: 'b', year: 2018, rating: 4.7 },
	{ title: 'c', year: 2018, rating: 3 },
	{ title: 'd', year: 2017, rating: 4.5 }
];

const sortedTitles = movies
	.filter((movie) => movie.year === 2018 && movie.rating >= 4)
	.sort((a, b) => a.rating - b.rating)
	.reverse()
	.map((movie) => movie.title);

console.log(sortedTitles)
*/

/*

// Function to get the sum of strings and also an array if array is passed as argument instead of a string.

function sum(...items) {
	if (items.length === 1 && Array.isArray(items[0])) {
		items = [ ...items[0] ];
	}
	return items.reduce((a, b) => a + b);
}

*/

/*
//Implement a try catch block to catch an error in this earlier written code to make sure the right data type is written.

try {
	const numbers = [ 1, 2, 3, 4, 2, 1, 3, 4, 1 ];
    const count = countOccurence2(numbers, 1);
    
    console.log(count);
    
} catch (e) {
	console.log(e.message);
}

function countOccurence2(array, searchElement) {
	if (!Array.isArray(array)) {
		throw new Error('This is not an array');
	}

	array.reduce((accumulator, currentValue) => {
		const occurence = currentValue === searchElement ? 1 : 0;
		return accumulator + occurence;
	}, 0);
}
*/