// OBJECT ORIENTED PROGRAMMING BASICS

// Factory function method of creating objects

function createCircle(radius) {
	return {
		radius,
		draw: function() {
			console.log('draw');
		}
	};
}

const circle = createCircle(1);

// Constructor Function method of creating objects.

function Circle(radius) {
	this.radius = radius;
	this.draw = function() {
		console.log('I am drawing');
	};
}

const anotherCircle = new Circle(1);

// Enumerating properties
// 1. enumerate members
for (let key in anotherCircle) {
	if (typeof circle[key] !== 'function') {
		console.log(key, anotherCircle[key]);
	}
}

// 2. getting the keys
const keys = Object.keys(anotherCircle);
console.log(keys);

// 3. checking for particular property
if ('radius' in circle) {
	console.log('Circle has a radius');
}

// ABSTRACTION - hide details and complexity and show the essentials

//closure determines what variables will be accesible to an inner function. **Closure is contrast of Scope**

function Circle(radius) {
	this.radius = radius;

	// using the 'let' or const keywords instead of 'this' helps us to define functions that are only accessible to the function scope and cannot be mutated from outside. This is analogous to 'private' settings in Java.

	let defaultLocation = { x: 0, y: 1 };

	let computeOptimumLocation = function(factor) {
		//....
	};

	this.draw = function() {
		// local variables available to the draw function only.
		let x, y;

		computeOptimumLocation(0.1);
		defaultLocation; // to access the closeure variables

		this.radius; // to access the closure values, we still use the this keyword.

		console.log('draw');

		//but the draw function can access the variables (defaultLocation and computeOptimumLocation) from its parent function - Circle - because of CLOSURE. Scope is temporary but closure stays longer.
	};
}

const circle = new Circle(10);
circle.draw();

// GETTERS AND SETTERS

function Circle(radius) {
	this.radius = radius;

	let defaultLocation = { x: 0, y: 1 };

	this.draw = function() {
		console.log('draw');
	};

	// to be able to access the inner variables and functions of the Circle functions outside the function, we use getters ( accessors) and to be able to change (mutate) them outside the function, we use setter (mutator)

	// the below method of getter can be used
	this.getDefaultLocation = function() {
		return defaultLocation;
	};

	// but a better way to define getters and setters is by using the following syntax - Object.defineProperty or Object.defineProperties...

	Object.defineProperties(this, 'defaultLocation', {
		get: function() {
			return defaultLocation;
		},
		set: function(value) {
			if (!value.x || !value.y) {
				throw new Error('Invalid location.');
			}

			defaultLocation = value;
		}
	});
}

const circle = new Circle(10);
circle.draw();

// STOPWATCH OBJECT EXAMPLE...

// this stopwatch has methods such as start, stop, reset, and a getter for the duration.

//declare the stopwatch function
function Stopwatch() {
	// Declaring the initial variables of the stopwatch function
	let startTime,
		endTime,
		running,
		duration = 0;

	// the start method
	this.start = function() {
		// throws an error if it has been called and is still running and then re-called
		if (running) {
			throw new Error(' Stopwatch is already running ');
		}

		// setting the initial value of the running to true
		running = true;

		// storing the starting time the method was called with the Date() method of JS.
		startTime = new Date();
	};

	// the stop method
	this.stop = function() {
		// error checking if the stop method is called while the stopwatch is not running
		if (!running) {
			throw new Error(' Stopwatch is not running ');
		}

		// initializing running to false as default because it is false unless the timer is running
		running = false;

		// store the time that we stopped the clock.
		endTime = new Date();

		// store the number of seconds that
		const seconds = endTime.getTime() - startTime.getTime() / 1000;

		// add the seconds to the duration.
		duration += seconds;
	};

	// reset method sets parameter to their initial value.

	this.reset = function() {
		startTime = null;
		endTime = null;
		running = false;
		duration = 0;
	};

	// Getter function to access the initial duration property.

	this.defineProperty(this, 'duration', {
		get: function() {
			return duration;
		}
	});
}

// I N H E R I T A N C E

// Classical versus Prototypical Inheritance: Classical inhetitance is when subclass inherit directly from the superclass like Java that uses "subclass extends superClass" because Java has classes the relationship is an is-a r/ship - "subclass is a superclass".

// Prototypical Inheritance is in Javascript because JS doesn't have classes rather it has Objects. Every object (except the root Object) has a Prototype or parent and inherits all the members, values and methods defined in its prototype.

// Multilevel Inheritance is when an object derives from a parent object which derives from another parent object till we get to the root object that derives from no object.

// Property Descriptors - configurable (delete if we wanted), enumerable (iterable), writable (overwrite, change its implementation). These attributes can be set like so:

let person = { name: 'Eze' };

Object.defineProperty(person, 'name', {
	writeable: false, //to make person object to be read-only.
	configurable: false, // person object can no longer be deleted
	enumerable: false // person object will be iterable if true but not-iterable if false.
});

person.name = 'Iji'; // Will not change the initial value
console.log(person); // still shows "name: Eze"
console.log(Object.keys(person)); // not show up; shows an empty array.

delete person.name; // nothing will happen cos configurable is false.

// PROTOTYPE VS INSTANCE MEMBERS

// When objects are created, methods can also be created inside them. But creating new objects from those objects can create numerous instances of methods inside of the objects, which is not good for performance. So, since there is multilevel inheritance of object to inherit from prototypes which inherits from the constructors till the root object that has no constructor, we can create the methods in the prototypes instead of the objects themselves so that when these methods are called, they will be looked for in the objects and if not found, they will be looked for in the prototypes and continue to go upwards till the root till they are found.

// Example:

function Circle(radius) {
	// Instance members
	this.radius = radius;
}

// Prototypical members
Circle.prototype.draw = function() {
	console.log('draw');
};

const c1 = new Circle(1);
const c2 = new Circle(1);

// the draw method may have been declared in the Circle function, but it will be in the prototype and can be accessed whenever a circle object is instantiated.

// We can also overwite the toString method (which every object has) just like Java.

Circle.prototype.toString = function() {
	return `Circle with radius ${this.radius}`;
};

// and even if we had an instance of toString in the Object based, the protypical toString will be used due to the hierarchy it has (easier accessibility).

// Prototypical and instance members can interact with each other.

// Iteration of Instance versus Prototype Variables.

// Object.keys returns instance members
console.log(Object.keys(c1));

// for...in loop returns both the instance and prototype members.
for (key in c1) {
	console.log(key);
}

// instance members are also called OwnProperty so,

c1.hasOwnProperty('radius'); // evaluates to 'true'

c1.hasOwnProperty('draw'); // evaluates to 'false'

// Inheritance:

function Shape() {}

Shape.prototype.duplicate = function() {
	console.log('duplicate');
};

function Circle(radius) {
	this.radius = radius;
}

Circle.prototype.draw = function() {
	console.log('draw');
};

// this is analogous to Circle extends Shape in Java.
Circle.prototype = Object.create(Shape.prototype);
// this makes it possible that the prototypical inheritance of Circle comes from Shape object and not the Object object.
// But as best practice, whenever we reset the prototype of an object, we should reset the constructor to the object we changed its prototype too. this is for dynamic implementation.
Circle.prototype.constructor = Circle;

const s = new Shape();
const c = new Circle(1); // Circle has all the methods of Circle (draw) and those of Shape (duplicate).

// CALLING THE SUPER CLASS CONSTRUCTOR.

function Shape(color) {
	this.color = color;
}

Shape.prototype.duplicate = function() {
	console.log('duplicate');
};

function Circle(radius, color) {
	// how to make a call to the super constructor

	Shape.call(this, color); // call was used because of the this in the Shape function.

	this.radius = radius;
}

Circle.prototype.draw = function() {
	console.log('draw');
};

Circle.prototype = Object.create(Shape.prototype);

Circle.prototype.constructor = Circle;

const s = new Shape();
const c = new Circle(1, 'red');

// INTERMEDIATE FUNCTION INHERITANCE.
// this uses extend function to wrap the 2 lines of code used to link a sub class to a super class.

function extend(Child, Parent) {
	Child.prototype = Object.create(Parent.prototype);
	Child.prototype.constructor = Child;
}

// So,
extend(Circle, Shape); // creates the child/parent inheritance and reset.

// Method Overriding
// we may have a method in the parent object that works well for most of the subclasses but not all of them. Overriding solves this issue.

// after the extend (Parent, Child) call:
extend(Circle, Shape);

Circle.prototype.duplicate = function() {
	Shape.prototype.duplicate.call(this); // if there is a 'this' in the Shape function.

	console.log('duplicate circle');
};

// P O L Y M O R P H I S M : Many forms

function Shape() {}

Shape.prototype.duplicate = function() {
	console.log('duplicate');
};

function Circle(radius, color) {
	Shape.call(this, color);
	this.radius = radius;
}

Circle.prototype.draw = function() {
	console.log('draw');
};

Circle.prototype = Object.create(Shape.prototype);
Circle.prototype.constructor = Circle;

const s = new Shape();
const c = new Circle(1, 'red');

extend(Circle, Shape);
Circle.prototype.duplicate = function() {
	console.log('duplicate circle');
};

extend(Square, Shape);
Square.prototype.duplicate = function() {
	console.log('duplicate square');
};

// If we create an array of shapes, and we want our to iterate in those shapes like so:

const shapes = [ new Circle(), new Square() ];

for (let shape of shapes) {
	console.log(shape.duplicate());
}

// the above code produces a list of duplicate outputs according to the shape that it is called from. So duplicate takes many forms - Polymorphism.

// M I X I N S - COMPOSITION.
function mixin(target, ...sources) {
	Object.assign(target, ...sources);
}

const canEat = {
	eat: function() {
		this.hunger--;
		console.log('eating');
	}
};

const canWalk = {
	walk: function() {
		console.log('walking');
	}
};

const canSwim = {
	swim: function() {
		console.log('swim');
	}
};

function Person() {}
mixin(Person.prototype, canEat, canWalk);
const person = new Person();
console.log(person);

function Goldfish() {}
mixin(Goldfish.prototype, canEat, canSwim);
const goldfish = new Goldfish();
console.log(goldfish);

// E X E R C I S E S
// Exercise 1...
// Practising

function HTMLElement() {
	this.click = function() {
		console.log('clicked');
	};
}

HTMLElement.prototype.focus = function() {
	console.log('focused');
};

function HTMLSelectElement(items = []) {
	this.items = items;

	this.addItem = function(item) {
		this.items.push(item);
	};

	this.removeItem = function(item) {
		this.items.splice(this.items.indexOf(item), 1);
	};

	// exercise 2's render method //
	this.render = function() {
		return `
    <select> ${this.items
		.map(
			(item) => `
        <option> ${item} </option>`
		)
		.join('')}
    </select>
        `;
	};
}

HTMLSelectElement.prototype = new HTMLElement();
// instead of
// HTMLSelectElement.prototype = Object.create(HTMLElement.prototype) This is because Object.create will create a new object and set the prototype of that object to the argument passed which is the prototype of the HTMLElement. Using the Object.create method would have made it impossible to inherit the click method in HTMLElement.

HTMLSelectElement.prototype.constructor = HTMLSelectElement;
// the left side of this equation is the same as new HTMLSelectElement().

// Exercise 2 - Polymorphism.
// .. continued from exercise 1

function HTMLImageElement(src) {
	this.src = src;

	this.render = function() {
		return `<img src= "${this.src}" />`;
	};
}

HTMLImageElement.prototype = new HTMLElement();
HTMLImageElement.prototype.constructor = HTMLImageElement;

// E S 6   C L A S S E S.

// Syntactic sugar for prototypical inheritance.

class Circle {
	constructor(radius) {
		this.radius = radius;

		// methods in the constructor show up in the object but outside the prototype
		this.draw = function() {
			console.log('draw');
		};
	}

	// methods here shows up in the prototype
	area() {
		return Math.PI * this.radius * this.radius;
	}

	// Static methods are used to create utility methods that are not specific to a particular object rather they are directly accessed when that class itself is about to be used.

	static round() {
		console.log('where');
	}
}

const c = new Circle(1);

// function expressions are not hoisted while function declarations are hoisted.
// In Classes, both class declarations and class expressions are NOT hoisted.

// Private Members Using Symbols

const _radius = Symbol();
const _draw = Symbol();

class Circle {
	constructor(radius) {
		this[_radius] = radius;
	}

	[_draw]() {}
}

const c = new Circle(1);
console.log(c[key]);

// Private Members Using WeakMaps ... come back and revwatch.

// Getters and Setters

const _radius = new WeakMap();

class Circle {
	constructor(radius) {
		_radius.set(this, radius);
	}

	get radius() {
		return _radius.get(this);
	}

	set radius(value) {
		if (value <= 0) {
			throw new Error('Invalid radius');
		}
		_radius.set(this, value);
	}
}

const c = new Circle(1);
// Comapre with previous getter and setter methods

// INHERITANCE WITH CLASSES

class Shape {
	constructor(color) {
		this.color = color;
	}

	move() {
		console.log('move');
	}
}

class Circle extends Shape {
	constructor(color, radius) {
		super(color);
		this.radius = radius;
	}

	draw() {
		console.log('draw');
	}
}

const c = new Circle('red', 1);

// OVERRIDING WITH CLASSES
// Just re-declare any method you need to override in the subclass and it will override the method in the supeclass. If you need the method in the superclass to be called from the subclass, use super.method() call inside the method declaration of the subclass. That way, you have access.

// EXERCISES

// Building a Stack with ES6 Classes.

const _items = new WeakMap();

class Stack {
	constructor() {
		_items.set(this, []);
	}

	push(object) {
		_items.get(this).push(object);
	}

	pop() {
		const items = _items.get(this);

		if (items.length === 0) {
			throw new Error('Stack is empty');
		}
		return items.pop();
	}

	peek() {
		const items = _items.get(this);

		if (items.length === 0) {
			throw new Error('Stack is empty');
		}
		return items[items.length - 1];
	}

	get count() {
		return _items.get(this).length;
	}
}

//  M  O  D  U  L  E  S

const _radius = new WeakMap();

class Circle {
	constructor(radius) {
		_radius.set(this, radius);
	}

	draw() {
		console.log('Circle with radius ' + _radius.get(this));
	}
}

const c = new Circle(10);
c.draw();


// Basic rules of Modularity: 
// Cohesion: Things that highly related go together.
// You basically treat the modules lie we do in Node. (a.) Put them in a separate file (b.) export with module.exports = Circle (c.) import them in the index.js or whereevr you are using them by calling const Circle = require('file path of where you saved the modules, usually ./module   - no extension(.js)).

//  E  S  6   -   M  O  D  U  L  E  S

// In ES6, the syntax for module is that we use the word 'export' before the class declaration and then use the line import ... from ./path in the file we want to use. 